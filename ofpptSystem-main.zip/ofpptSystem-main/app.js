const loginBtn = document.querySelector("#logToAcc");

loginBtn.onclick = () => {
  location.href = "/index.html";
};
